export const getBrandName = () => "TESS Agency";
export const getHomePageTitle = () => "TESS Agency";
export const getHomePageDescription = () => "TESS Agency";
export const getBrandLogo = () => "/amazonfbasetup.png";
export const getWhatsApp = () => "12175955859";
export const getCalendlyLink = () => "https://calendly.com/tessagency";
export const getSlogan  = () => "Powered by TESS";
