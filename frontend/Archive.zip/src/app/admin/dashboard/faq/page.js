import React from 'react';
import AdminFAQSection from "@/components/AdminFAQSection";

const Page = () => {
  return (
    <div>
      <AdminFAQSection />

    </div>
  );
};

export default Page;