import React from 'react';
import CarouselUpload from "@/components/BrandUpload";

const Page = () => {
  return (
    <div>
      <CarouselUpload/>

    </div>
  );
};

export default Page;