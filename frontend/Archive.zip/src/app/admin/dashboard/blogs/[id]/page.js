import React from 'react';
import EditBlog from "@/components/EditBlog";

const Page = () => {
  return (
    <div>
			<EditBlog />
    </div>
  );
};

export default Page;