"use client"
import React from 'react';
import AddBlog from "@/components/AddBlog";

const Page = () => {
  return (
    <div>
      <AddBlog/>
    </div>
  );
};

export default Page;